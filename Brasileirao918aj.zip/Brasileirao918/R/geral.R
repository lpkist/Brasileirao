geral <- function(){
tab_geral <- column(12,
                      h1("Análise Geral"),

                    h2("o fur n trabalha")
                      # Conteúdo do Slide de Modelos aqui
)
}
