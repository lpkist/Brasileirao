arbitro <- function(){
tab_arbitro <- column(12,
                    h1("Árbitro")
                    # Conteúdo do Slide de Modelos aqui
)
}
