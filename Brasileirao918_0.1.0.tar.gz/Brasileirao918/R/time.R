time <- function(){
tab_time <- column(12,
                      h1("Time")
                      # Conteúdo do Slide de Modelos aqui
)
}
