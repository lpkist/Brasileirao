campeonato <- function(){
tab_campeonato <- column(12,
                      h1("Campeonato")
                      # Conteúdo do Slide de Modelos aqui
)
}
