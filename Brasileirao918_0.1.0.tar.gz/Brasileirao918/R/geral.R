geral <- function(){
tab_geral <- column(12,
                      h1("Análise Geral")
                      # Conteúdo do Slide de Modelos aqui
)
}
